
package com.proyecto.sistemadesalud.entity;

import jakarta.persistence.*;

@Entity
@Table(name = "medico")
public class Medico extends Persona {

    @Column(nullable = false, length = 100)
    private String especialidad;

    @Column(name = "tarjeta_profesional", length = 50)
    private String tarjetaProfesional;

    public String getEspecialidad() {
        return especialidad;
    }

    public void setEspecialidad(String especialidad) {
        this.especialidad = especialidad;
    }

    public String getTarjetaProfesional() {
        return tarjetaProfesional;
    }

    public void setTarjetaProfesional(String tarjetaProfesional) {
        this.tarjetaProfesional = tarjetaProfesional;
    }

    @Override
    public String getDescripcion() {
        return "Dr(a). " + getPrimerNombre() + " "
                + getPrimerApellido() + " - " + especialidad;
    }
}
