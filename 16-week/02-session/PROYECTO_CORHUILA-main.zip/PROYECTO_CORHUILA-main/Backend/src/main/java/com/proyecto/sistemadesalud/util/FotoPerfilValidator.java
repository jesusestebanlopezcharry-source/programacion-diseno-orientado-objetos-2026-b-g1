
package com.proyecto.sistemadesalud.util;

import org.springframework.http.HttpStatus;
import org.springframework.web.server.ResponseStatusException;

import java.util.Base64;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public final class FotoPerfilValidator {

    private static final int MAX_BYTES = 512 * 1024;

    private static final Pattern FORMATO_IMAGEN = Pattern.compile(
            "^data:image/(jpeg|png|webp);base64,([A-Za-z0-9+/]+={0,2})$"
    );

    private FotoPerfilValidator() {
    }

    public static String validarYNormalizar(String fotoPerfil) {

        if (fotoPerfil == null || fotoPerfil.isBlank()) {
            return null;
        }

        Matcher matcher = FORMATO_IMAGEN.matcher(fotoPerfil);

        if (!matcher.matches()) {
            throw new ResponseStatusException(
                    HttpStatus.BAD_REQUEST,
                    "La fotografía debe ser JPEG, PNG o WebP en formato Base64"
            );
        }

        try {
            byte[] imagen = Base64.getDecoder().decode(matcher.group(2));

            if (imagen.length == 0 || imagen.length > MAX_BYTES) {
                throw new ResponseStatusException(
                        HttpStatus.BAD_REQUEST,
                        "La fotografía no puede superar los 512 KB"
                );
            }

            return fotoPerfil;

        } catch (IllegalArgumentException e) {
            throw new ResponseStatusException(
                    HttpStatus.BAD_REQUEST,
                    "La fotografía tiene un contenido Base64 inválido"
            );
        }
    }
}
