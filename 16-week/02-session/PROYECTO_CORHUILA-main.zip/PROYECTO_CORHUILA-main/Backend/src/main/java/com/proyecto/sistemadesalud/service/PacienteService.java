
package com.proyecto.sistemadesalud.service;

import com.proyecto.sistemadesalud.entity.Medico;
import com.proyecto.sistemadesalud.entity.Paciente;
import com.proyecto.sistemadesalud.exception.RecursoNoEncontradoException;
import com.proyecto.sistemadesalud.repository.PacienteRepository;

import com.proyecto.sistemadesalud.util.FotoPerfilValidator;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;

@Service
public class PacienteService {

    private static final int TAMANO_PAGINA = 20;

    private final PacienteRepository repository;

    public PacienteService(PacienteRepository repository) {
        this.repository = repository;
    }

    // Listar pacientes con paginación
    public Page<Paciente> listar(int pagina) {

        Pageable pageable = PageRequest.of(
                pagina,
                TAMANO_PAGINA,
                Sort.by("id").ascending()
        );

        return repository.findByStatus("ACTIVO", pageable);
    }

    // Buscar paciente por ID
    public Paciente buscarPorId(Integer id) {
        return repository.findById(id)
                .orElseThrow(() ->
                        new RecursoNoEncontradoException("Paciente no encontrado"));
    }

    // Registrar paciente
    public Paciente guardar(Paciente paciente) {

        paciente.setFotoPerfil(
                FotoPerfilValidator.validarYNormalizar(paciente.getFotoPerfil())
        );

        paciente.setStatus("ACTIVO");

        return repository.save(paciente);
    }

    // Listar pacientes archivados con paginación
    public Page<Paciente> listarArchivados(int pagina) {
        Pageable pageable = PageRequest.of(
                pagina,
                TAMANO_PAGINA,
                Sort.by("id").ascending()
        );
        return repository.findByStatus("INACTIVO", pageable);
    }

    // Restaurar paciente archivado
    public Paciente restaurar(Integer id) {
        Paciente paciente = buscarPorId(id);
        if ("ACTIVO".equals(paciente.getStatus())) {
            throw new IllegalStateException("El paciente ya se encuentra activo");
        }
        paciente.setStatus("ACTIVO");
        return repository.save(paciente);
    }

    // Actualizar paciente
    public Paciente actualizar(Integer id, Paciente datos) {

        Paciente paciente = buscarPorId(id);
        if (!"ACTIVO".equals(paciente.getStatus())) {
            throw new IllegalStateException("No se puede modificar un paciente archivado");
        }

        // Datos heredados de Persona
        paciente.setTipoDocumento(datos.getTipoDocumento());
        paciente.setNumeroDocumento(datos.getNumeroDocumento());

        paciente.setPrimerNombre(datos.getPrimerNombre());
        paciente.setSegundoNombre(datos.getSegundoNombre());

        paciente.setPrimerApellido(datos.getPrimerApellido());
        paciente.setSegundoApellido(datos.getSegundoApellido());

        paciente.setTelefono(datos.getTelefono());
        paciente.setCorreo(datos.getCorreo());
        if (datos.getFotoPerfil() != null) {
            paciente.setFotoPerfil(
                    FotoPerfilValidator.validarYNormalizar(datos.getFotoPerfil())
            );
        }


        // Datos propios de Paciente
        paciente.setFechaNacimiento(datos.getFechaNacimiento());
        paciente.setSexo(datos.getSexo());
        paciente.setMunicipioDane(datos.getMunicipioDane());
        paciente.setDireccion(datos.getDireccion());
        paciente.setRegimenAfiliacion(datos.getRegimenAfiliacion());
        paciente.setAseguradora(datos.getAseguradora());

        paciente.setAcudienteNombre(datos.getAcudienteNombre());
        paciente.setAcudienteTelefono(datos.getAcudienteTelefono());

        paciente.setGrupoSanguineo(datos.getGrupoSanguineo());
        paciente.setAlergias(datos.getAlergias());
        paciente.setHistorialClinico(datos.getHistorialClinico());

        return repository.save(paciente);
    }



    // Archivar paciente (no se elimina de la base de datos)
    public Paciente archivar(Integer id) {

        Paciente paciente = buscarPorId(id);

        if ("INACTIVO".equals(paciente.getStatus())) {
            throw new IllegalStateException(
                    "El paciente ya se encuentra archivado"
            );
        }

        paciente.setStatus("INACTIVO");

        return repository.save(paciente);
    }

}
