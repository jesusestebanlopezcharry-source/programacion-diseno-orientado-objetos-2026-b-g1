
package com.proyecto.sistemadesalud.controller;

import com.proyecto.sistemadesalud.entity.Cita;
import com.proyecto.sistemadesalud.service.CitaService;

import org.springframework.data.domain.Page;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/citas")
public class CitaController {

    private final CitaService service;

    public CitaController(CitaService service) {
        this.service = service;
    }

    // Listar citas con paginación
    @GetMapping
    public Page<Cita> listar(
            @RequestParam(defaultValue = "0") int pagina) {

        return service.listar(pagina);
    }

    // Agrupar citas por médico
    @GetMapping("/por-medico")
    public Map<String, List<Cita>> porMedico() {
        return service.agruparPorMedico();
    }

    // Crear cita
    @PostMapping
    public Cita crear(@RequestBody Cita cita) {
        return service.crear(cita);
    }

    // Cambiar estado
    @PutMapping("/{id}/estado/{valor}")
    public Cita cambiarEstado(
            @PathVariable Integer id,
            @PathVariable String valor) {

        return service.cambiarEstado(id, valor);
    }

    // Eliminar cita
    @DeleteMapping("/{id}")
    public void eliminar(@PathVariable Integer id) {
        service.eliminar(id);
    }
}
