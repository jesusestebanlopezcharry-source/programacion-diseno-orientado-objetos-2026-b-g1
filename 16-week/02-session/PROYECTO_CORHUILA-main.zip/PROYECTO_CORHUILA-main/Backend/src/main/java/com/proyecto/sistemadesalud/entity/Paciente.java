package com.proyecto.sistemadesalud.entity;

import jakarta.persistence.*;
import java.time.LocalDate;

@Entity
@Table(name = "paciente")
public class Paciente extends Persona {

    @Column(name = "fecha_nacimiento")
    private LocalDate fechaNacimiento;

    @Column(name = "sexo", length = 15)
    private String sexo;

    @Column(name = "municipio_dane", length = 10)
    private String municipioDane;

    @Column(name = "direccion", length = 180)
    private String direccion;

    @Column(name = "regimen_afiliacion", length = 30)
    private String regimenAfiliacion;

    @Column(name = "aseguradora", length = 120)
    private String aseguradora;

    @Column(name = "acudiente_nombre", length = 150)
    private String acudienteNombre;

    @Column(name = "acudiente_telefono", length = 25)
    private String acudienteTelefono;

    @Column(name = "grupo_sanguineo", length = 10)
    private String grupoSanguineo;

    @Column(columnDefinition = "TEXT")
    private String alergias;

    @Column(name = "historial_clinico", columnDefinition = "TEXT")
    private String historialClinico;

    public LocalDate getFechaNacimiento() { return fechaNacimiento; }
    public void setFechaNacimiento(LocalDate fechaNacimiento) { this.fechaNacimiento = fechaNacimiento; }

    public String getSexo() { return sexo; }
    public void setSexo(String sexo) { this.sexo = sexo; }

    public String getMunicipioDane() { return municipioDane; }
    public void setMunicipioDane(String municipioDane) { this.municipioDane = municipioDane; }

    public String getDireccion() { return direccion; }
    public void setDireccion(String direccion) { this.direccion = direccion; }

    public String getRegimenAfiliacion() { return regimenAfiliacion; }
    public void setRegimenAfiliacion(String regimenAfiliacion) { this.regimenAfiliacion = regimenAfiliacion; }

    public String getAseguradora() { return aseguradora; }
    public void setAseguradora(String aseguradora) { this.aseguradora = aseguradora; }

    public String getAcudienteNombre() { return acudienteNombre; }
    public void setAcudienteNombre(String acudienteNombre) { this.acudienteNombre = acudienteNombre; }

    public String getAcudienteTelefono() { return acudienteTelefono; }
    public void setAcudienteTelefono(String acudienteTelefono) { this.acudienteTelefono = acudienteTelefono; }

    public String getGrupoSanguineo() { return grupoSanguineo; }
    public void setGrupoSanguineo(String grupoSanguineo) { this.grupoSanguineo = grupoSanguineo; }

    public String getAlergias() { return alergias; }
    public void setAlergias(String alergias) { this.alergias = alergias; }

    public String getHistorialClinico() { return historialClinico; }
    public void setHistorialClinico(String historialClinico) { this.historialClinico = historialClinico; }

    @Override
    public String getDescripcion() {
        return "Paciente: " + getPrimerNombre() + " " + getPrimerApellido();
    }
}