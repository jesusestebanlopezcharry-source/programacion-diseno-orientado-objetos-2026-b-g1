
package com.proyecto.sistemadesalud.controller;

import com.proyecto.sistemadesalud.entity.Paciente;
import com.proyecto.sistemadesalud.service.PacienteService;

import org.springframework.data.domain.Page;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/pacientes")
public class PacienteController {

    private final PacienteService service;

    public PacienteController(PacienteService service) {
        this.service = service;
    }

    // Listar pacientes con paginación
    @GetMapping
    public Page<Paciente> listar(
            @RequestParam(defaultValue = "0") int pagina) {

        return service.listar(pagina);
    }

    // Listar pacientes archivados
    @GetMapping("/archivados")
    public Page<Paciente> listarArchivados(
            @RequestParam(defaultValue = "0") int pagina) {
        return service.listarArchivados(pagina);
    }

    // Restaurar paciente archivado
    @PatchMapping("/{id}/restaurar")
    public Paciente restaurar(@PathVariable Integer id) {
        return service.restaurar(id);
    }

    // Buscar paciente por ID
    @GetMapping("/{id}")
    public Paciente buscarPorId(@PathVariable Integer id) {
        return service.buscarPorId(id);
    }

    // Registrar paciente
    @PostMapping
    public Paciente crear(@RequestBody Paciente paciente) {
        return service.guardar(paciente);
    }

    // Actualizar paciente
    @PutMapping("/{id}")
    public Paciente actualizar(
            @PathVariable Integer id,
            @RequestBody Paciente paciente) {

        return service.actualizar(id, paciente);
    }

    // Archivar paciente (el registro se conserva)
    @PatchMapping("/{id}/archivar")
    public Paciente archivar(@PathVariable Integer id) {
        return service.archivar(id);
    }
}
