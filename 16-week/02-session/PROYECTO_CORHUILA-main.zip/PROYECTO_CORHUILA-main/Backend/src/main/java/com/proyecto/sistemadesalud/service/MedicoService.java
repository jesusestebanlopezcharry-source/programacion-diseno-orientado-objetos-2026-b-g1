
package com.proyecto.sistemadesalud.service;

import com.proyecto.sistemadesalud.entity.Medico;
import com.proyecto.sistemadesalud.exception.RecursoNoEncontradoException;
import com.proyecto.sistemadesalud.repository.MedicoRepository;

import com.proyecto.sistemadesalud.util.FotoPerfilValidator;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;

@Service
public class MedicoService {

    private static final int TAMANO_PAGINA = 20;

    private final MedicoRepository repository;

    public MedicoService(MedicoRepository repository) {
        this.repository = repository;
    }

    // Listar médicos con paginación
    public Page<Medico> listar(int pagina) {

        Pageable pageable = PageRequest.of(
                pagina,
                TAMANO_PAGINA,
                Sort.by("id").ascending()
        );

        return repository.findByStatus("ACTIVO", pageable);
    }

    // Buscar médico por ID
    public Medico buscarPorId(Integer id) {
        return repository.findById(id)
                .orElseThrow(() ->
                        new RecursoNoEncontradoException("Médico no encontrado"));
    }

    // Registrar médico
    public Medico guardar(Medico medico) {

        medico.setFotoPerfil(
                FotoPerfilValidator.validarYNormalizar(medico.getFotoPerfil())
        );

        medico.setStatus("ACTIVO");

        return repository.save(medico);
    }

    // Listar médicos archivados con paginación
    public Page<Medico> listarArchivados(int pagina) {
        Pageable pageable = PageRequest.of(
                pagina,
                TAMANO_PAGINA,
                Sort.by("id").ascending()
        );
        return repository.findByStatus("INACTIVO", pageable);
    }

    // Restaurar médico archivado
    public Medico restaurar(Integer id) {
        Medico medico = buscarPorId(id);
        if ("ACTIVO".equals(medico.getStatus())) {
            throw new IllegalStateException("El médico ya se encuentra activo");
        }
        medico.setStatus("ACTIVO");
        return repository.save(medico);
    }

    // Actualizar médico
    public Medico actualizar(Integer id, Medico datos) {

        Medico medico = buscarPorId(id);
        if (!"ACTIVO".equals(medico.getStatus())) {
            throw new IllegalStateException("No se puede modificar un médico archivado");
        }

        // Datos personales heredados de Persona
        medico.setTipoDocumento(datos.getTipoDocumento());
        medico.setNumeroDocumento(datos.getNumeroDocumento());

        medico.setPrimerNombre(datos.getPrimerNombre());
        medico.setSegundoNombre(datos.getSegundoNombre());

        medico.setPrimerApellido(datos.getPrimerApellido());
        medico.setSegundoApellido(datos.getSegundoApellido());

        medico.setTelefono(datos.getTelefono());
        medico.setCorreo(datos.getCorreo());
        if (datos.getFotoPerfil() != null) {
            medico.setFotoPerfil(
                    FotoPerfilValidator.validarYNormalizar(datos.getFotoPerfil())
            );
        }


        // Datos propios del médico
        medico.setEspecialidad(datos.getEspecialidad());
        medico.setTarjetaProfesional(datos.getTarjetaProfesional());

        return repository.save(medico);
    }

    // Archivar médico (no elimina físicamente el registro)

    // Archivar médico (no se elimina de la base de datos)
    public Medico archivar(Integer id) {

        Medico medico = buscarPorId(id);

        if ("INACTIVO".equals(medico.getStatus())) {
            throw new IllegalStateException(
                    "El médico ya se encuentra archivado"
            );
        }

        medico.setStatus("INACTIVO");

        return repository.save(medico);
    }

}
