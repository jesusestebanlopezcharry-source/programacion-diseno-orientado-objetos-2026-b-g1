
package com.proyecto.sistemadesalud.service;

import com.proyecto.sistemadesalud.entity.Cita;
import com.proyecto.sistemadesalud.entity.Medico;
import com.proyecto.sistemadesalud.entity.Paciente;
import com.proyecto.sistemadesalud.exception.CitaInvalidaException;
import com.proyecto.sistemadesalud.exception.RecursoNoEncontradoException;
import com.proyecto.sistemadesalud.repository.CitaRepository;
import com.proyecto.sistemadesalud.repository.MedicoRepository;
import com.proyecto.sistemadesalud.repository.PacienteRepository;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.Period;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Service
public class CitaService {

    private static final int TAMANO_PAGINA = 20;
    private static final int EDAD_MAYORIA = 18;

    private final CitaRepository citaRepository;
    private final PacienteRepository pacienteRepository;
    private final MedicoRepository medicoRepository;

    public CitaService(
            CitaRepository citaRepository,
            PacienteRepository pacienteRepository,
            MedicoRepository medicoRepository) {

        this.citaRepository = citaRepository;
        this.pacienteRepository = pacienteRepository;
        this.medicoRepository = medicoRepository;
    }

    // Listar citas con paginación
    public Page<Cita> listar(int pagina) {

        Pageable pageable = PageRequest.of(
                pagina,
                TAMANO_PAGINA,
                Sort.by("fechaHora").descending()
        );

        return citaRepository.findAll(pageable);
    }

    // Buscar cita por ID
    public Cita buscarPorId(Integer id) {

        return citaRepository.findById(id)
                .orElseThrow(() ->
                        new RecursoNoEncontradoException(
                                "Cita no encontrada"));
    }

    // Crear cita
    public Cita crear(Cita cita) {

        if (cita.getPaciente() == null
                || cita.getMedico() == null
                || cita.getPaciente().getId() == null
                || cita.getMedico().getId() == null) {

            throw new CitaInvalidaException(
                    "Debe indicar paciente y médico");
        }

        Paciente paciente = pacienteRepository
                .findById(cita.getPaciente().getId())
                .orElseThrow(() ->
                        new RecursoNoEncontradoException(
                                "Paciente no encontrado"));

        Medico medico = medicoRepository
                .findById(cita.getMedico().getId())
                .orElseThrow(() ->
                        new RecursoNoEncontradoException(
                                "Médico no encontrado"));

        // No permitir nuevas citas con pacientes archivados
        if (!"ACTIVO".equals(paciente.getStatus())) {
            throw new CitaInvalidaException(
                    "No se pueden crear citas con un paciente archivado");
        }

        // No permitir nuevas citas con médicos archivados
        if (!"ACTIVO".equals(medico.getStatus())) {
            throw new CitaInvalidaException(
                    "No se pueden crear citas con un médico archivado");
        }

        validarFecha(cita.getFechaHora());

        validarMedicoLibre(
                medico.getId(),
                cita.getFechaHora()
        );

        validarAcompanante(paciente, cita);

        cita.setPaciente(paciente);
        cita.setMedico(medico);
        cita.setEstado(Cita.PROGRAMADA);

        return citaRepository.save(cita);
    }

    // Cambiar estado de una cita
    public Cita cambiarEstado(Integer id, String estado) {

        boolean valido =
                Cita.PROGRAMADA.equals(estado)
                        || Cita.ATENDIDA.equals(estado)
                        || Cita.CANCELADA.equals(estado);

        if (!valido) {
            throw new CitaInvalidaException(
                    "Estado no válido: " + estado);
        }

        Cita cita = buscarPorId(id);

        if (Cita.INACTIVA.equals(cita.getEstado())) {
            throw new CitaInvalidaException(
                    "La cita está archivada y no se puede modificar");
        }

        cita.setEstado(estado);

        return citaRepository.save(cita);
    }

    // Archivar cita (no elimina físicamente el registro)
    public void eliminar(Integer id) {

        Cita cita = buscarPorId(id);

        if (Cita.PROGRAMADA.equals(cita.getEstado())) {
            throw new CitaInvalidaException(
                    "Una cita programada debe cancelarse o atenderse antes de archivarla");
        }

        cita.setEstado(Cita.INACTIVA);

        citaRepository.save(cita);
    }

    // Agrupar citas por médico
    public Map<String, List<Cita>> agruparPorMedico() {

        Map<String, List<Cita>> resultado = new HashMap<>();

        for (Cita cita : citaRepository.findAll()) {

            String medico = cita.getMedico().getDescripcion();

            resultado.computeIfAbsent(
                    medico,
                    k -> new ArrayList<>()
            ).add(cita);
        }

        return resultado;
    }

    // Validar fecha de la cita
    private void validarFecha(LocalDateTime fechaHora) {

        if (fechaHora == null
                || fechaHora.isBefore(LocalDateTime.now())) {

            throw new CitaInvalidaException(
                    "La fecha de la cita debe ser futura");
        }
    }

    // Validar disponibilidad del médico
    private void validarMedicoLibre(
            Integer medicoId,
            LocalDateTime fechaHora) {

        if (citaRepository.existsByMedicoIdAndFechaHoraAndEstadoIn(
                medicoId,
                fechaHora,
                List.of(Cita.PROGRAMADA, Cita.ATENDIDA))) {

            throw new CitaInvalidaException(
                    "El médico ya tiene una cita a esa hora");
        }
    }

    // Validar acompañante para menores de edad
    private void validarAcompanante(
            Paciente paciente,
            Cita cita) {

        if (paciente.getFechaNacimiento() == null) {
            return;
        }

        int edad = Period.between(
                paciente.getFechaNacimiento(),
                LocalDate.now()
        ).getYears();

        if (edad >= EDAD_MAYORIA) {
            return;
        }

        String nombre = cita.getAcompananteNombre();

        if (nombre == null || nombre.isBlank()) {

            throw new CitaInvalidaException(
                    "El paciente es menor de edad, debe registrar un acompañante");
        }
    }
}
