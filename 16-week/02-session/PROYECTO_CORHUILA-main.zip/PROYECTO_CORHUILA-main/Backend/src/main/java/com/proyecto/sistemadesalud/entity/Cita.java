package com.proyecto.sistemadesalud.entity;

import jakarta.persistence.*;
import java.time.LocalDateTime;

@Entity
@Table(name = "cita")
public class Cita {

    public static final String PROGRAMADA = "PROGRAMADA";
    public static final String ATENDIDA = "ATENDIDA";
    public static final String CANCELADA = "CANCELADA";
    public static final String INACTIVA = "INACTIVA";

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer id;

    @ManyToOne
    @JoinColumn(name = "paciente_id", nullable = false)
    private Paciente paciente;

    @ManyToOne
    @JoinColumn(name = "medico_id", nullable = false)
    private Medico medico;

    @Column(name = "fecha_hora", nullable = false)
    private LocalDateTime fechaHora;

    @Column(nullable = false, length = 200)
    private String motivo;

    @Column(nullable = false, length = 20)
    private String estado = PROGRAMADA;

    @Column(name = "acompanante_nombre", length = 150)
    private String acompananteNombre;

    @Column(name = "acompanante_identificacion", length = 20)
    private String acompananteIdentificacion;

    @Column(name = "acompanante_parentesco", length = 50)
    private String acompananteParentesco;

    public Integer getId() { return id; }
    public void setId(Integer id) { this.id = id; }

    public Paciente getPaciente() { return paciente; }
    public void setPaciente(Paciente paciente) { this.paciente = paciente; }

    public Medico getMedico() { return medico; }
    public void setMedico(Medico medico) { this.medico = medico; }

    public LocalDateTime getFechaHora() { return fechaHora; }
    public void setFechaHora(LocalDateTime fechaHora) { this.fechaHora = fechaHora; }

    public String getMotivo() { return motivo; }
    public void setMotivo(String motivo) { this.motivo = motivo; }

    public String getEstado() { return estado; }
    public void setEstado(String estado) { this.estado = estado; }

    public String getAcompananteNombre() { return acompananteNombre; }
    public void setAcompananteNombre(String acompananteNombre) { this.acompananteNombre = acompananteNombre; }

    public String getAcompananteIdentificacion() { return acompananteIdentificacion; }
    public void setAcompananteIdentificacion(String acompananteIdentificacion) { this.acompananteIdentificacion = acompananteIdentificacion; }

    public String getAcompananteParentesco() { return acompananteParentesco; }
    public void setAcompananteParentesco(String acompananteParentesco) { this.acompananteParentesco = acompananteParentesco; }
}
