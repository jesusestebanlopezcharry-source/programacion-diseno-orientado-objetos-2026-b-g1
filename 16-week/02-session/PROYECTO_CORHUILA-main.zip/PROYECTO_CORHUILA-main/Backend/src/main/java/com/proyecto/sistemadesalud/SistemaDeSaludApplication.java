package com.proyecto.sistemadesalud;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SistemaDeSaludApplication {

    public static void main(String[] args) {
        SpringApplication.run(SistemaDeSaludApplication.class, args);
    }
}