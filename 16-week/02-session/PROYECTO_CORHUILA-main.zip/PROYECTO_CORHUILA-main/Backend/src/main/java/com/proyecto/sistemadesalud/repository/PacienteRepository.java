
package com.proyecto.sistemadesalud.repository;

import com.proyecto.sistemadesalud.entity.Paciente;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;

public interface PacienteRepository extends JpaRepository<Paciente, Integer> {

    Page<Paciente> findByStatus(String status, Pageable pageable);

}
