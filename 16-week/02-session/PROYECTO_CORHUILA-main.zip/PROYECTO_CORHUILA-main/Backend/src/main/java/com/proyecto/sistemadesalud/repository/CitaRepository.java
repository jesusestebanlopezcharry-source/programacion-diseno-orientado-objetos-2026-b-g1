package com.proyecto.sistemadesalud.repository;

import com.proyecto.sistemadesalud.entity.Cita;
import org.springframework.data.jpa.repository.JpaRepository;
import java.time.LocalDateTime;
import java.util.Collection;
import java.util.List;

public interface CitaRepository extends JpaRepository<Cita, Integer> {

    boolean existsByMedicoIdAndFechaHoraAndEstadoIn(
            Integer medicoId,
            LocalDateTime fechaHora,
            Collection<String> estados
    );

}
