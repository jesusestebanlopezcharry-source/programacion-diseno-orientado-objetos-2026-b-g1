
package com.proyecto.sistemadesalud.repository;

import com.proyecto.sistemadesalud.entity.Medico;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;

public interface MedicoRepository extends JpaRepository<Medico, Integer> {

    Page<Medico> findByStatus(String status, Pageable pageable);

}
