
package com.proyecto.sistemadesalud.controller;

import com.proyecto.sistemadesalud.entity.Medico;
import com.proyecto.sistemadesalud.service.MedicoService;

import org.springframework.data.domain.Page;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/medicos")
public class MedicoController {

    private final MedicoService service;

    public MedicoController(MedicoService service) {
        this.service = service;
    }

    // Listar médicos con paginación
    @GetMapping
    public Page<Medico> listar(
            @RequestParam(defaultValue = "0") int pagina) {

        return service.listar(pagina);
    }

    // Listar médicos archivados
    @GetMapping("/archivados")
    public Page<Medico> listarArchivados(
            @RequestParam(defaultValue = "0") int pagina) {
        return service.listarArchivados(pagina);
    }

    // Restaurar médico archivado
    @PatchMapping("/{id}/restaurar")
    public Medico restaurar(@PathVariable Integer id) {
        return service.restaurar(id);
    }

    // Buscar médico por ID
    @GetMapping("/{id}")
    public Medico buscarPorId(@PathVariable Integer id) {
        return service.buscarPorId(id);
    }

    // Registrar médico
    @PostMapping
    public Medico crear(@RequestBody Medico medico) {
        return service.guardar(medico);
    }

    // Actualizar médico
    @PutMapping("/{id}")
    public Medico actualizar(
            @PathVariable Integer id,
            @RequestBody Medico medico) {

        return service.actualizar(id, medico);
    }

    // Archivar médico (el registro se conserva)
    @PatchMapping("/{id}/archivar")
    public Medico archivar(@PathVariable Integer id) {
        return service.archivar(id);
    }
}
