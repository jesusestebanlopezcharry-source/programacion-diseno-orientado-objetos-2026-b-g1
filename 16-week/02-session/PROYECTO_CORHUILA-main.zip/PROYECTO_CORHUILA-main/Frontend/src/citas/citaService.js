import api, { obtenerTodasLasPaginas } from "../shared/api";
import { citaDesdeApi } from "../shared/normalizadores";

export const listarCitas = async () =>
  (await obtenerTodasLasPaginas("/citas")).map(citaDesdeApi);

export const crearCita = (datos) => api.post("/citas", datos);
export const cambiarEstadoCita = (id, estado) => api.put(`/citas/${id}/estado/${estado}`);
export const eliminarCita = (id) => api.delete(`/citas/${id}`);
export const listarCitasPorMedico = async () => {
  const respuesta = await api.get("/citas/por-medico");
  return Object.fromEntries(
    Object.entries(respuesta.data || {}).map(([nombre, lista]) => [
      nombre,
      (lista || []).map(citaDesdeApi),
    ])
  );
};
