import { useMemo, useState } from "react";
import Campo from "../shared/Campo";

import { calcularEdad, hora } from "../shared/utils";
import { EDAD_MAYORIA, ESTADO_ATENDIDA, ESTADO_PROGRAMADA } from "../shared/constantes";

const MAX_MOTIVO = 200;
const VACIO = { pacienteId: "", medicoId: "", fecha: "", hora: "", motivo: "", acompananteNombre: "", acompananteIdentificacion: "", acompananteParentesco: "" };

function SelectorPersona({ etiqueta, personas, valor, onChange, tipo }) {
  const [busqueda, setBusqueda] = useState("");
  const [abierto, setAbierto] = useState(false);
  const seleccionado = personas.find((p) => String(p.id) === String(valor));
  const coincidencias = useMemo(() => personas.filter((p) =>
    `${p.nombre} ${p.apellido} ${p.tipoDocumento} ${p.identificacion} ${p.especialidad || ""}`
      .toLowerCase().includes(busqueda.trim().toLowerCase())
  ).slice(0, 40), [personas, busqueda]);

  return (
    <div className="selector-persona">
      <Campo etiqueta={etiqueta} completo>
        <div className="selector-entrada">
          <input
            value={abierto ? busqueda : seleccionado ? `${seleccionado.nombre} ${seleccionado.apellido} — ${seleccionado.tipoDocumento} ${seleccionado.identificacion}` : ""}
            onFocus={() => { setAbierto(true); setBusqueda(""); }}
            onChange={(e) => { setBusqueda(e.target.value); setAbierto(true); }}
            placeholder={tipo === "paciente" ? "Buscar paciente por nombre o cédula..." : "Buscar médico por nombre, cédula o especialidad..."}
            autoComplete="off"
            required={!valor}
          />
          {valor && <button type="button" className="selector-limpiar" onClick={() => { onChange(""); setBusqueda(""); setAbierto(true); }}>Cambiar</button>}
        </div>
      </Campo>
      {abierto && <div className="selector-resultados">
        {coincidencias.length ? coincidencias.map((p) => <button type="button" key={p.id}
          className="selector-opcion" onClick={() => { onChange(String(p.id)); setBusqueda(""); setAbierto(false); }}>
          <span className="selector-inicial">{(p.nombre || "?").charAt(0)}{(p.apellido || "?").charAt(0)}</span>
          <span><strong>{p.nombre} {p.apellido}</strong><small>{p.tipoDocumento} {p.identificacion}{p.especialidad ? ` · ${p.especialidad}` : ""}</small></span>
        </button>) : <p className="selector-sin-resultados">No se encontraron coincidencias.</p>}
        <button type="button" className="selector-cerrar" onClick={() => setAbierto(false)}>Cerrar resultados</button>
      </div>}
      {seleccionado && !abierto && <p className="selector-seleccionado">Seleccionado: {seleccionado.nombre} {seleccionado.apellido}</p>}
    </div>
  );
}

function opcionesHora() {
  const horas = [];
  for (let h = 0; h < 24; h += 1) {
    for (const m of [0, 15, 30, 45]) {
      horas.push(`${String(h).padStart(2, "0")}:${String(m).padStart(2, "0")}`);
    }
  }
  return horas;
}

export default function CitaForm({ pacientes, medicos, citas = [], error, onGuardar, onCerrar }) {
  const [form, setForm] = useState(VACIO);
  const hoy = new Date().toLocaleDateString("sv-SE");
  const paciente = pacientes.find((p) => p.id === Number(form.pacienteId));
  const edad = paciente?.fechaNacimiento ? calcularEdad(paciente.fechaNacimiento) : null;
  const esMenor = edad !== null && edad < EDAD_MAYORIA;
  const horas = opcionesHora();
  const ocupadas = new Set(citas
      .filter((c) => (c.estado === ESTADO_PROGRAMADA || c.estado === ESTADO_ATENDIDA)
      && String(c.medico?.id) === String(form.medicoId)
      && c.fechaHora?.slice(0, 10) === form.fecha)
    .map((c) => c.fechaHora.slice(11, 16)));
  const disponibles = horas.filter((h) =>
    (form.fecha !== hoy || h > new Date().toTimeString().slice(0, 5)) && !ocupadas.has(h)
  );

  function cambiar(campo, valor) { setForm((actual) => ({ ...actual, [campo]: valor })); }
  function enviar(e) {
    e.preventDefault();
    if (!form.fecha || !form.hora) return;
    onGuardar({
      paciente: { id: Number(form.pacienteId) },
      medico: { id: Number(form.medicoId) },
      fechaHora: `${form.fecha}T${form.hora}:00`,
      motivo: form.motivo.trim(),
      acompananteNombre: esMenor ? form.acompananteNombre : null,
      acompananteIdentificacion: esMenor ? form.acompananteIdentificacion : null,
      acompananteParentesco: esMenor ? form.acompananteParentesco : null,
    });
  }

  return (
    <form onSubmit={enviar} className="formulario formulario-cita">
      {error && <p className="error">{error}</p>}
      <div className="seccion-formulario"><h2>Personas de la cita</h2><p>Busca y selecciona por nombre o número de documento.</p></div>
      <SelectorPersona etiqueta="Paciente" tipo="paciente" personas={pacientes} valor={form.pacienteId} onChange={(v) => cambiar("pacienteId", v)} />
      <SelectorPersona etiqueta="Médico" tipo="medico" personas={medicos} valor={form.medicoId} onChange={(v) => cambiar("medicoId", v)} />

      <div className="seccion-formulario"><h2>Fecha y hora</h2><p>Selecciona el día y elige una hora en intervalos de 15 minutos.</p></div>
      <Campo etiqueta="Fecha de la cita">
        <input type="date" min={hoy} value={form.fecha} onChange={(e) => { cambiar("fecha", e.target.value); cambiar("hora", ""); }} required />
      </Campo>
      <div className="campo campo-completo">
        <span>Selecciona una hora</span>
        {!form.fecha || !form.medicoId ? <p className="ayuda-campo">Selecciona una fecha y un médico para consultar las horas libres.</p> :
          disponibles.length === 0 ? <p className="ayuda-campo">No hay horas libres para esta fecha y médico. Selecciona otro día o profesional.</p> :
          <div className="horarios-grid">{disponibles.map((h) => <button type="button" key={h}
            className={form.hora === h ? "hora-opcion hora-opcion-activa" : "hora-opcion"}
            onClick={() => cambiar("hora", h)}>{hora(`${form.fecha}T${h}:00`)}</button>)}</div>}
        {form.hora && <p className="horario-elegido">Horario seleccionado: <strong>{form.hora}</strong></p>}
      </div>

      <Campo etiqueta={`Motivo de la consulta (${form.motivo.length}/${MAX_MOTIVO})`} completo>
        <textarea name="motivo" rows={4} maxLength={MAX_MOTIVO} value={form.motivo}
          onChange={(e) => cambiar("motivo", e.target.value)} required placeholder="Describe brevemente el motivo de la consulta." />
      </Campo>

      {esMenor && <div className="bloque-menor">
        <p><strong>{paciente.nombre} tiene {edad} años.</strong> Por ser menor de edad debe asistir con un acompañante.</p>
        <Campo etiqueta="Nombre del acompañante" completo><input value={form.acompananteNombre} onChange={(e) => cambiar("acompananteNombre", e.target.value)} required /></Campo>
        <Campo etiqueta="Documento del acompañante"><input value={form.acompananteIdentificacion} onChange={(e) => cambiar("acompananteIdentificacion", e.target.value)} required /></Campo>
        <Campo etiqueta="Parentesco"><input placeholder="Mamá, papá, abuelo..." value={form.acompananteParentesco} onChange={(e) => cambiar("acompananteParentesco", e.target.value)} /></Campo>
      </div>}
      <div className="formulario-acciones">
        <button type="button" className="btn btn-suave" onClick={onCerrar}>Cancelar</button>
        <button type="submit" className="btn btn-primario" disabled={!form.pacienteId || !form.medicoId || !form.fecha || !form.hora}>Agendar cita</button>
      </div>
    </form>
  );
}
