import { useEffect, useMemo, useState } from "react";
import { mensajeError } from "../shared/api";

import Avatar from "../shared/Avatar";
import Confirmar from "../shared/Confirmar";
import { IconoBuscar, IconoMas, IconoPapelera } from "../shared/Iconos";
import {
  ESTADO_ATENDIDA,
  ESTADO_CANCELADA,
  ESTADO_INACTIVA,
  ESTADO_PROGRAMADA,
  ETIQUETA_ESTADO
} from "../shared/constantes";
import useAviso from "../shared/useAviso";
import { hoyISO, hora, nombreDia } from "../shared/utils";
import { listarPacientes } from "../pacientes/pacienteService";
import { listarMedicos } from "../medicos/medicoService";
import CitaForm from "./CitaForm";
import { listarCitas, crearCita, cambiarEstadoCita, eliminarCita } from "./citaService";

const TODAS = "TODAS";
const VISTAS = [
  { id: "fecha", texto: "Por fecha" },
  { id: "medico", texto: "Por médico" },
  { id: "especialidad", texto: "Por especialidad" },
];
const FILTROS = [
  { valor: ESTADO_PROGRAMADA, texto: "Programadas" },
  { valor: ESTADO_ATENDIDA, texto: "Atendidas" },
  { valor: ESTADO_CANCELADA, texto: "Canceladas" },
  { valor: TODAS, texto: "Todas" },
  { valor: ESTADO_INACTIVA, texto: "Historial" },
];

function nombreCompleto(p = {}) { return `${p.nombre || ""} ${p.apellido || ""}`.trim(); }
function agrupar(citas, obtenerClave) {
  const grupos = new Map();
  citas.forEach((c) => {
    const clave = obtenerClave(c) || "Sin clasificar";
    if (!grupos.has(clave)) grupos.set(clave, []);
    grupos.get(clave).push(c);
  });
  return [...grupos.entries()].sort(([a], [b]) => a.localeCompare(b, "es"));
}

function TarjetaCita({ cita, cambiarEstado, eliminar }) {
  return <li className={`cita cita-${cita.estado}`}>
    <div className="cita-hora">{hora(cita.fechaHora)}</div>
    <div className="cita-detalle">
      <div className="persona"><Avatar nombre={cita.paciente.nombre} apellido={cita.paciente.apellido} fotoPerfil={cita.paciente.fotoPerfil} /><div>
        <strong>{nombreCompleto(cita.paciente)}</strong>
        <span className="texto-suave">{cita.paciente.tipoDocumento} {cita.paciente.identificacion}</span>
        <span className="texto-suave">Con {nombreCompleto(cita.medico)} · {cita.medico.especialidad}</span>
      </div></div>
      <p className="cita-motivo">{cita.motivo}</p>
      {cita.acompananteNombre && <p className="texto-suave">Acompañante: {cita.acompananteNombre}{cita.acompananteParentesco ? ` (${cita.acompananteParentesco})` : ""}</p>}
    </div>
    <div className="cita-lado">
      <span className={`etiqueta estado-${cita.estado}`}>{ETIQUETA_ESTADO[cita.estado] || cita.estado}</span>
      <div className="acciones">
        {cita.estado === ESTADO_PROGRAMADA && <>
          <button className="btn btn-pequeno btn-verde" onClick={() => cambiarEstado(cita, ESTADO_ATENDIDA)}>Marcar atendida</button>
          <button className="btn btn-pequeno btn-suave" onClick={() => cambiarEstado(cita, ESTADO_CANCELADA)}>Cancelar cita</button>
        </>}
        {(cita.estado === ESTADO_ATENDIDA || cita.estado === ESTADO_CANCELADA) &&
            <button className="btn btn-pequeno btn-suave" onClick={() => eliminar(cita)}>Archivar</button>}
      </div>
    </div>
  </li>;
}

export default function CitasPage() {
  const [citas, setCitas] = useState([]);
  const [pacientes, setPacientes] = useState([]);
  const [medicos, setMedicos] = useState([]);
  const [cargando, setCargando] = useState(true);
  const [vista, setVista] = useState("fecha");
  const [filtro, setFiltro] = useState(ESTADO_PROGRAMADA);
  const [busqueda, setBusqueda] = useState("");
  const [formularioAbierto, setFormularioAbierto] = useState(false);
  const [porEliminar, setPorEliminar] = useState(null);
  const [error, setError] = useState("");
  const { aviso, mostrar, cerrar } = useAviso();

  async function cargar() {
    try { setCitas(await listarCitas()); }
    catch { mostrar("No se pudieron cargar las citas. Verifica que el backend esté ejecutándose.", "error"); }
    finally { setCargando(false); }
  }

  useEffect(() => {
    cargar();
    listarPacientes().then(setPacientes).catch(() => mostrar("No se pudieron cargar los pacientes.", "error"));
    listarMedicos().then(setMedicos).catch(() => mostrar("No se pudieron cargar los médicos.", "error"));
  }, []);

  async function guardar(datos) {
    setError("");
    try {
      await crearCita(datos);
      mostrar("Cita agendada correctamente");
      setFormularioAbierto(false);
      setFiltro(ESTADO_PROGRAMADA);
      await cargar();
    } catch (err) { setError(mensajeError(err)); }
  }

  async function cambiarEstado(cita, estado) {
    try {
      await cambiarEstadoCita(cita.id, estado);
      mostrar(estado === ESTADO_ATENDIDA ? "Cita marcada como atendida" : "Cita cancelada");
      await cargar();
    } catch (err) { mostrar(mensajeError(err), "error"); }
  }

  async function eliminar() {
    try { await eliminarCita(porEliminar.id); mostrar("Cita archivada en el historial"); await cargar(); }
    catch (err) { mostrar(mensajeError(err), "error"); }
    setPorEliminar(null);
  }

  const visibles = useMemo(() => {
    const termino = busqueda.trim().toLowerCase();
    return citas.filter((c) => {
      const estadoOk = filtro === TODAS ? c.estado !== ESTADO_INACTIVA : c.estado === filtro;
      const texto = [
        nombreCompleto(c.paciente), c.paciente.tipoDocumento, c.paciente.identificacion,
        nombreCompleto(c.medico), c.medico.tipoDocumento, c.medico.identificacion,
        c.medico.especialidad, c.motivo,
      ].join(" ").toLowerCase();
      return estadoOk && (!termino || texto.includes(termino));
    }).sort((a, b) => a.fechaHora.localeCompare(b.fechaHora));
  }, [citas, filtro, busqueda]);

  const grupos = useMemo(() => {
    if (vista === "medico") return agrupar(visibles, (c) => nombreCompleto(c.medico));
    if (vista === "especialidad") return agrupar(visibles, (c) => c.medico.especialidad);
    return agrupar(visibles, (c) => c.fechaHora.slice(0, 10));
  }, [visibles, vista]);

  const hoy = hoyISO();
  const programadas = citas.filter((c) => c.estado === ESTADO_PROGRAMADA).length;
  const citasHoy = citas.filter((c) => c.estado === ESTADO_PROGRAMADA && c.fechaHora.startsWith(hoy)).length;
  const contar = (valor) => valor === TODAS ? citas.filter((c) => c.estado !== ESTADO_INACTIVA).length : citas.filter((c) => c.estado === valor).length;

  return <div>
    <header className="pagina-cabecera">
      <div><h1>Agenda de citas</h1><p className="subtitulo">{programadas} programada(s) · {citasHoy} para hoy</p></div>
      {!formularioAbierto && <button className="btn btn-primario" onClick={() => { setError(""); setFormularioAbierto(true); window.scrollTo({ top: 0, behavior: "smooth" }); }}><IconoMas /> Nueva cita</button>}
    </header>

    {formularioAbierto && <section className="formulario-panel">
      <header className="formulario-panel-cabecera"><div><span className="sobrelinea">AGENDA MÉDICA</span><h2>Agendar una cita</h2><p>Selecciona al paciente, al profesional y el horario de atención.</p></div>
        <button className="btn btn-suave" onClick={() => setFormularioAbierto(false)}>Cerrar formulario</button></header>
      {pacientes.length === 0 || medicos.length === 0 ? <div className="aviso-formulario">Para agendar una cita necesitas tener al menos un paciente y un médico activos.</div> :
        <CitaForm pacientes={pacientes} medicos={medicos} citas={citas} error={error} onGuardar={guardar} onCerrar={() => setFormularioAbierto(false)} />}
    </section>}

    <div className="vistas" role="tablist" aria-label="Agrupar citas">
      {VISTAS.map((v) => <button key={v.id} role="tab" aria-selected={vista === v.id}
        className={vista === v.id ? "vista vista-activa" : "vista"} onClick={() => setVista(v.id)}>{v.texto}</button>)}
    </div>

    <div className="herramientas">
      <div className="filtros" role="tablist">{FILTROS.map((f) => <button key={f.valor} role="tab" aria-selected={filtro === f.valor}
        className={filtro === f.valor ? "filtro filtro-activo" : "filtro"} onClick={() => setFiltro(f.valor)}>
        {f.texto}<span className="filtro-cuenta">{contar(f.valor)}</span></button>)}</div>
      <div className="buscador buscador-citas"><IconoBuscar /><input placeholder="Buscar por paciente, cédula, médico o especialidad..." value={busqueda} onChange={(e) => setBusqueda(e.target.value)} /></div>
    </div>

    {cargando ? <p className="vacio">Cargando agenda...</p> : citas.length === 0 ?
      <div className="vacio"><h3>La agenda está vacía</h3><p>Agenda la primera cita. Necesitas tener un paciente y un médico registrados.</p>
        <button className="btn btn-primario" onClick={() => setFormularioAbierto(true)}><IconoMas /> Nueva cita</button></div> :
      visibles.length === 0 ? <p className="vacio">No hay citas que coincidan con los filtros o la búsqueda.</p> :
      grupos.map(([clave, lista]) => <section key={clave} className={vista === "fecha" ? "dia" : "medico-grupo"}>
        {vista === "fecha" ? <h2 className="dia-titulo">{nombreDia(clave)}{clave === hoy && <span className="marca-hoy">Hoy</span>}</h2> :
          <header className="medico-grupo-cabecera"><div><h2>{clave}</h2>
            <span className="texto-suave">{vista === "especialidad" ? "Especialidad médica" : lista[0].medico.especialidad}</span></div>
            <span className="etiqueta etiqueta-primaria">{lista.length} {lista.length === 1 ? "cita" : "citas"}</span></header>}
        <ul className="citas-lista">{lista.map((c) => <TarjetaCita key={c.id} cita={c} cambiarEstado={cambiarEstado} eliminar={setPorEliminar} />)}</ul>
      </section>)
    }

    <Confirmar pregunta={porEliminar ? "¿Archivar esta cita?" : null}
               detalle="Saldrá de la agenda y quedará guardada en el Historial. No se borra."
               textoBoton="Archivar cita" onConfirmar={eliminar} onCancelar={() => setPorEliminar(null)} />
  </div>;
}
