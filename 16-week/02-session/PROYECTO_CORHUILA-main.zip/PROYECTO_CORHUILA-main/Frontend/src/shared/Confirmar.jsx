// Ventana para confirmar acciones que no se pueden deshacer
export default function Confirmar({ pregunta, detalle, textoBoton, onConfirmar, onCancelar }) {
  if (!pregunta) return null;

  return (
    <div className="modal-fondo" onClick={onCancelar}>
      <div className="modal" role="alertdialog" aria-label={pregunta} onClick={(e) => e.stopPropagation()}>
        <h3>{pregunta}</h3>
        {detalle && <p>{detalle}</p>}
        <div className="modal-acciones">
          <button className="btn btn-suave" onClick={onCancelar}>Volver</button>
          <button className="btn btn-peligro" onClick={onConfirmar}>{textoBoton}</button>
        </div>
      </div>
    </div>
  );
}
