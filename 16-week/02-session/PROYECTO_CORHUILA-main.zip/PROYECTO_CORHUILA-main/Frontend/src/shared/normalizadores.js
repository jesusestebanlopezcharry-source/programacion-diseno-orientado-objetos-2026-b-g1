// Convierte los nombres reales del backend a nombres sencillos para la interfaz.
export function personaDesdeApi(p = {}) {
  return {
    ...p,
    identificacion: p.numeroDocumento ?? "",
    nombre: [p.primerNombre, p.segundoNombre].filter(Boolean).join(" "),
    apellido: [p.primerApellido, p.segundoApellido].filter(Boolean).join(" "),
  };
}

export function pacienteDesdeApi(p = {}) {
  return personaDesdeApi(p);
}

export function medicoDesdeApi(m = {}) {
  return personaDesdeApi(m);
}

export function citaDesdeApi(c = {}) {
  return {
    ...c,
    paciente: pacienteDesdeApi(c.paciente || {}),
    medico: medicoDesdeApi(c.medico || {}),
  };
}

export function personaHaciaApi(datos = {}) {
  const nombres = (datos.nombre || "").trim().split(/\s+/).filter(Boolean);
  const apellidos = (datos.apellido || "").trim().split(/\s+/).filter(Boolean);
  return {
    tipoDocumento: datos.tipoDocumento,
    numeroDocumento: datos.identificacion,
    primerNombre: nombres[0] || "",
    segundoNombre: nombres.slice(1).join(" ") || null,
    primerApellido: apellidos[0] || "",
    segundoApellido: apellidos.slice(1).join(" ") || null,
    telefono: datos.telefono || null,
    correo: datos.correo || null,
    fotoPerfil: datos.fotoPerfil || null,
    status: "ACTIVO",
  };
}

export function pacienteHaciaApi(datos = {}) {
  return {
    ...personaHaciaApi(datos),
    fechaNacimiento: datos.fechaNacimiento || null,
    sexo: datos.sexo || null,
    municipioDane: datos.municipioDane || null,
    direccion: datos.direccion || null,
    regimenAfiliacion: datos.regimenAfiliacion || null,
    aseguradora: datos.aseguradora || null,
    acudienteNombre: datos.acudienteNombre || null,
    acudienteTelefono: datos.acudienteTelefono || null,
    grupoSanguineo: datos.grupoSanguineo || null,
    alergias: datos.alergias || null,
    historialClinico: datos.historialClinico || null,
  };
}

export function medicoHaciaApi(datos = {}) {
  return {
    ...personaHaciaApi(datos),
    especialidad: datos.especialidad,
    tarjetaProfesional: datos.tarjetaProfesional || null,
  };
}
