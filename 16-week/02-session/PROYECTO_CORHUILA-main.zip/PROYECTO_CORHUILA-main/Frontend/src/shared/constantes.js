// Valores fijos que se usan en varias pantallas

export const TIPOS_DOCUMENTO = ["CC", "TI", "CE", "RC", "PA"];
export const TIPOS_DOCUMENTO_MEDICO = ["CC", "CE", "PA"];

export const ESPECIALIDADES = [
  "Medicina General",
  "Pediatría",
  "Cardiología",
  "Dermatología",
  "Odontología",
];

export const EDAD_MAYORIA = 18;

export const ESTADO_PROGRAMADA = "PROGRAMADA";
export const ESTADO_ATENDIDA = "ATENDIDA";
export const ESTADO_CANCELADA = "CANCELADA";
export const ESTADO_INACTIVA = "INACTIVA";

export const ETIQUETA_ESTADO = {
  PROGRAMADA: "Programada",
  ATENDIDA: "Atendida",
  CANCELADA: "Cancelada",
  INACTIVA: "Archivada",
};
