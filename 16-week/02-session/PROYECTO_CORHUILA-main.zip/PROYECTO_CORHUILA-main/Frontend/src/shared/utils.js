// Funciones pequeñas de ayuda para fechas y nombres

export function calcularEdad(fechaNacimiento) {
  const hoy = new Date();
  const nacimiento = new Date(fechaNacimiento);
  let edad = hoy.getFullYear() - nacimiento.getFullYear();
  const aunNoCumple =
    hoy.getMonth() < nacimiento.getMonth() ||
    (hoy.getMonth() === nacimiento.getMonth() && hoy.getDate() < nacimiento.getDate());
  return aunNoCumple ? edad - 1 : edad;
}

function mayuscula(texto) {
  return texto.charAt(0).toUpperCase() + texto.slice(1);
}

// "Martes, 17 de noviembre"
export function fechaLarga(fecha) {
  return mayuscula(
    fecha.toLocaleDateString("es-CO", { weekday: "long", day: "numeric", month: "long" })
  );
}

// Recibe "2026-11-17"
export function nombreDia(fechaISO) {
  return fechaLarga(new Date(`${fechaISO}T00:00:00`));
}

// Fecha de hoy como "2026-11-17"
export function hoyISO() {
  return new Date().toLocaleDateString("sv-SE");
}

// "9:00 a. m."
export function hora(fechaHora) {
  return new Date(fechaHora).toLocaleTimeString("es-CO", {
    hour: "numeric",
    minute: "2-digit",
    hour12: true,
  });
}
