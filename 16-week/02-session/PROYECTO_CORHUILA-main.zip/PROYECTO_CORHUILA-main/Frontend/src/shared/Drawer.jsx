import { useEffect } from "react";
import { IconoCerrar } from "./Iconos";

// Panel lateral que se abre desde la derecha (se cierra con Esc o tocando afuera)
export default function Drawer({ abierto, titulo, onCerrar, children }) {
  useEffect(() => {
    if (!abierto) return;
    function alPulsar(e) {
      if (e.key === "Escape") onCerrar();
    }
    document.addEventListener("keydown", alPulsar);
    return () => document.removeEventListener("keydown", alPulsar);
  }, [abierto, onCerrar]);

  if (!abierto) return null;

  return (
    <div className="drawer-fondo" onClick={onCerrar}>
      <aside
        className="drawer"
        role="dialog"
        aria-modal="true"
        aria-label={titulo}
        onClick={(e) => e.stopPropagation()}
      >
        <header className="drawer-cabecera">
          <h2>{titulo}</h2>
          <button className="btn-icono" onClick={onCerrar} aria-label="Cerrar panel">
            <IconoCerrar />
          </button>
        </header>
        <div className="drawer-cuerpo">{children}</div>
      </aside>
    </div>
  );
}
