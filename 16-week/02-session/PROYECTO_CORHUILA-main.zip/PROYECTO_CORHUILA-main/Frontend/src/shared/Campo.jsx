// Un campo de formulario con su título arriba
export default function Campo({ etiqueta, completo = false, children }) {
  return (
    <label className={completo ? "campo campo-completo" : "campo"}>
      <span>{etiqueta}</span>
      {children}
    </label>
  );
}
