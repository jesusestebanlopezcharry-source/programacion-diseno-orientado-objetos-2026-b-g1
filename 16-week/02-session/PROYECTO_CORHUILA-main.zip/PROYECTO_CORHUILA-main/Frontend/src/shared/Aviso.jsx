import { useEffect } from "react";

// Mensaje flotante: "Paciente registrado", etc.
export default function Aviso({ aviso, onCerrar }) {
  useEffect(() => {
    if (!aviso) return;
    const temporizador = setTimeout(onCerrar, 3500);
    return () => clearTimeout(temporizador);
  }, [aviso, onCerrar]);

  if (!aviso) return null;

  return (
    <div className={`aviso aviso-${aviso.tipo}`} role="status">
      {aviso.texto}
    </div>
  );
}
