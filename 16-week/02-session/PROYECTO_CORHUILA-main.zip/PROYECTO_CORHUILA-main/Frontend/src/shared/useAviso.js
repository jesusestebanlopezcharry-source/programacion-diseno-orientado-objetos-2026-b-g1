import { useCallback, useState } from "react";

// Mensaje corto que aparece abajo a la derecha y se va solo
export default function useAviso() {
  const [aviso, setAviso] = useState(null);

  const mostrar = useCallback((texto, tipo = "ok") => setAviso({ texto, tipo }), []);
  const cerrar = useCallback(() => setAviso(null), []);

  return { aviso, mostrar, cerrar };
}
