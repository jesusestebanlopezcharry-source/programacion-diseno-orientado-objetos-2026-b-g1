import { useEffect, useRef, useState } from "react";

const MAX_ARCHIVO_MB = 8;
const MAX_BYTES = 500 * 1024; // Margen frente al límite de 512 KB del backend.
const TAMANOS = [480, 420, 360, 320];
const CALIDADES = [0.82, 0.72, 0.62, 0.52];

function canvasComoDataUrl(canvas) {
  for (const calidad of CALIDADES) {
    const dataUrl = canvas.toDataURL("image/jpeg", calidad);
    const prefijo = "data:image/jpeg;base64,";
    const bytes = Math.ceil((dataUrl.length - prefijo.length) * 3 / 4);
    if (bytes <= MAX_BYTES) return dataUrl;
  }
  return null;
}

function recortarImagen(imagen, ancho, alto, tamano) {
  const lado = Math.min(ancho, alto);
  const sx = (ancho - lado) / 2;
  const sy = (alto - lado) / 2;
  const canvas = document.createElement("canvas");
  canvas.width = tamano;
  canvas.height = tamano;
  const contexto = canvas.getContext("2d");
  contexto.drawImage(imagen, sx, sy, lado, lado, 0, 0, tamano, tamano);
  return canvas;
}

function comprimirImagen(imagen, ancho, alto) {
  for (const tamano of TAMANOS) {
    const resultado = canvasComoDataUrl(recortarImagen(imagen, ancho, alto, tamano));
    if (resultado) return resultado;
  }
  throw new Error("No se pudo comprimir la fotografía al tamaño permitido. Prueba con otra imagen.");
}

async function archivoComoDataUrl(archivo) {
  if (!archivo.type.startsWith("image/")) {
    throw new Error("Selecciona un archivo de imagen válido.");
  }
  if (archivo.size > MAX_ARCHIVO_MB * 1024 * 1024) {
    throw new Error(`La imagen original supera ${MAX_ARCHIVO_MB} MB. Selecciona una más pequeña.`);
  }

  if ("createImageBitmap" in window) {
    const imagen = await createImageBitmap(archivo);
    try {
      return comprimirImagen(imagen, imagen.width, imagen.height);
    } finally {
      imagen.close?.();
    }
  }

  return new Promise((resolve, reject) => {
    const imagen = new Image();
    const url = URL.createObjectURL(archivo);
    imagen.onload = () => {
      URL.revokeObjectURL(url);
      try {
        resolve(comprimirImagen(imagen, imagen.naturalWidth, imagen.naturalHeight));
      } catch (error) {
        reject(error);
      }
    };
    imagen.onerror = () => {
      URL.revokeObjectURL(url);
      reject(new Error("No se pudo leer la imagen."));
    };
    imagen.src = url;
  });
}

export default function FotoPerfil({ value = "", onChange, nombre = "persona" }) {
  const videoRef = useRef(null);
  const streamRef = useRef(null);
  const archivoRef = useRef(null);
  const [camaraAbierta, setCamaraAbierta] = useState(false);
  const [procesando, setProcesando] = useState(false);
  const [error, setError] = useState("");

  function detenerCamara() {
    streamRef.current?.getTracks().forEach((pista) => pista.stop());
    streamRef.current = null;
    if (videoRef.current) videoRef.current.srcObject = null;
    setCamaraAbierta(false);
  }

  useEffect(() => {
    if (camaraAbierta && videoRef.current && streamRef.current) {
      videoRef.current.srcObject = streamRef.current;
      videoRef.current.play().catch(() => {});
    }
  }, [camaraAbierta]);

  useEffect(() => () => {
    streamRef.current?.getTracks().forEach((pista) => pista.stop());
  }, []);

  async function abrirCamara() {
    setError("");
    if (!navigator.mediaDevices?.getUserMedia) {
      setError("El navegador no permite acceder a la cámara. Usa localhost o HTTPS, o selecciona una imagen.");
      return;
    }
    try {
      const flujo = await navigator.mediaDevices.getUserMedia({
        audio: false,
        video: { facingMode: "user", width: { ideal: 1280 }, height: { ideal: 720 } },
      });
      streamRef.current = flujo;
      setCamaraAbierta(true);
    } catch (e) {
      const mensaje = e.name === "NotAllowedError"
        ? "No se concedió permiso para usar la cámara. Puedes habilitarlo en el navegador o subir una imagen."
        : "No se pudo acceder a la cámara. Comprueba que esté conectada y que ninguna otra aplicación la esté usando.";
      setError(mensaje);
    }
  }

  function capturar() {
    const video = videoRef.current;
    if (!video || !video.videoWidth) {
      setError("La cámara todavía no está lista. Inténtalo de nuevo en un momento.");
      return;
    }
    try {
      const foto = comprimirImagen(video, video.videoWidth, video.videoHeight);
      onChange(foto);
      setError("");
      detenerCamara();
    } catch (err) {
      setError(err.message || "No se pudo procesar la fotografía.");
    }
  }

  async function seleccionarArchivo(e) {
    const archivo = e.target.files?.[0];
    if (!archivo) return;
    setProcesando(true);
    setError("");
    try {
      const dataUrl = await archivoComoDataUrl(archivo);
      onChange(dataUrl);
    } catch (err) {
      setError(err.message || "No se pudo procesar la imagen.");
    } finally {
      setProcesando(false);
      e.target.value = "";
    }
  }

  return (
    <section className="foto-perfil campo-completo" aria-label={`Fotografía de ${nombre}`}>
      <div className="foto-perfil-vista">
        {camaraAbierta ? (
          <video ref={videoRef} className="foto-perfil-imagen foto-perfil-video" autoPlay muted playsInline />
        ) : value ? (
          <img className="foto-perfil-imagen" src={value} alt={`Fotografía de ${nombre}`} />
        ) : (
          <div className="foto-perfil-vacio" aria-hidden="true"><span>+</span></div>
        )}
      </div>
      <div className="foto-perfil-contenido">
        <div>
          <strong>Fotografía de perfil</strong>
          <p>{camaraAbierta ? "Ubícate frente a la cámara y captura la imagen." : "Toma una fotografía con la cámara o selecciona una desde tu dispositivo."}</p>
        </div>
        <div className="foto-perfil-acciones">
          {camaraAbierta ? (
            <>
              <button type="button" className="btn btn-primario btn-pequeno" onClick={capturar}>Capturar fotografía</button>
              <button type="button" className="btn btn-suave btn-pequeno" onClick={detenerCamara}>Cancelar</button>
            </>
          ) : (
            <>
              <button type="button" className="btn btn-primario btn-pequeno" onClick={abrirCamara}>Abrir cámara</button>
              <button type="button" className="btn btn-suave btn-pequeno" onClick={() => archivoRef.current?.click()} disabled={procesando}>
                {procesando ? "Procesando…" : "Subir imagen"}
              </button>
              {value && <button type="button" className="btn btn-suave btn-pequeno" onClick={() => onChange("")}>Quitar foto</button>}
            </>
          )}
          <input ref={archivoRef} type="file" accept="image/*" capture="user" hidden onChange={seleccionarArchivo} />
        </div>
        <span className="foto-perfil-ayuda">La imagen se convierte a JPEG y se comprime para enviarse al sistema (máximo 500 KB).</span>
        {error && <p className="foto-perfil-error" role="alert">{error}</p>}
      </div>
    </section>
  );
}
