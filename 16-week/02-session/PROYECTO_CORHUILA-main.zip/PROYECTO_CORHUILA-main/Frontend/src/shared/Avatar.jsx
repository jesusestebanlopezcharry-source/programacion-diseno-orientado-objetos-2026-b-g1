const COLORES = ["#0F7B73", "#3D5A98", "#B4543A", "#7A5C99", "#4C7D3A", "#A06A12"];

// Círculo con las iniciales de la persona; el color depende del nombre
export default function Avatar({ nombre = "", apellido = "", fotoPerfil = "" }) {
  const iniciales = `${nombre.charAt(0)}${apellido.charAt(0)}`.toUpperCase();
  const suma = [...(nombre + apellido)].reduce((total, letra) => total + letra.charCodeAt(0), 0);

  return (
    <span className="avatar" style={{ background: COLORES[suma % COLORES.length] }}>
      {fotoPerfil ? <img src={fotoPerfil} alt={`Fotografía de ${nombre} ${apellido}`} /> : iniciales}
    </span>
  );
}
