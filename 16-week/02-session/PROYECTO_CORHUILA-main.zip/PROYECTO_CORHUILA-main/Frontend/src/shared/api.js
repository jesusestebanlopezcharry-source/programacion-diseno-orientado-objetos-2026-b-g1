import axios from "axios";

const api = axios.create({
  baseURL: import.meta.env.VITE_API_URL || "http://localhost:8080",
  headers: { "Content-Type": "application/json" },
});

export function mensajeError(err) {
  return err.response?.data?.error
    || err.response?.data?.message
    || "No se pudo completar la acción. Revisa los datos e inténtalo otra vez.";
}

// El backend pagina los listados de personas y citas. Se recorren las páginas
// para que el buscador trabaje sobre todos los registros, no solo sobre los primeros 20.
export async function obtenerTodasLasPaginas(url) {
  const primera = await api.get(url, { params: { pagina: 0 } });
  const data = primera.data;
  if (Array.isArray(data)) return data;
  if (!data || !Array.isArray(data.content)) return [];
  const resultados = [...data.content];
  const totalPaginas = data.totalPages || 1;
  for (let pagina = 1; pagina < totalPaginas; pagina += 1) {
    const respuesta = await api.get(url, { params: { pagina } });
    resultados.push(...(respuesta.data?.content || []));
  }
  return resultados;
}

export default api;
