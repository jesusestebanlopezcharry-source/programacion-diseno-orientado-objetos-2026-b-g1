import { NavLink, Navigate, Route, Routes } from "react-router-dom";
import CitasPage from "./citas/CitasPage";
import PacientesPage from "./pacientes/PacientesPage";
import MedicosPage from "./medicos/MedicosPage";
import { IconoCalendario, IconoMedico, IconoPaciente } from "./shared/Iconos";
import { fechaLarga } from "./shared/utils";

export default function App() {
  return (
    <div className="app">
      <aside className="barra-lateral">
        <div className="marca">
          <span className="marca-logo">
            <IconoMedico />
          </span>
          <span className="marca-nombre">Agenda Médica</span>
        </div>

        <nav className="navegacion">
          <NavLink to="/citas" className="enlace">
            <IconoCalendario /> Citas
          </NavLink>
          <NavLink to="/pacientes" className="enlace">
            <IconoPaciente /> Pacientes
          </NavLink>
          <NavLink to="/medicos" className="enlace">
            <IconoMedico /> Médicos
          </NavLink>
        </nav>

        <p className="fecha-hoy">{fechaLarga(new Date())}</p>
      </aside>

      <main className="contenido">
        <Routes>
          <Route path="/" element={<Navigate to="/citas" />} />
          <Route path="/citas" element={<CitasPage />} />
          <Route path="/pacientes" element={<PacientesPage />} />
          <Route path="/medicos" element={<MedicosPage />} />
        </Routes>
      </main>
    </div>
  );
}
