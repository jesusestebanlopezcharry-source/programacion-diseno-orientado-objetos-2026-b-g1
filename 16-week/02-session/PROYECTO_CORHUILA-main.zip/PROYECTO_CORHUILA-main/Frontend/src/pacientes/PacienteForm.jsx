import { useState } from "react";
import Campo from "../shared/Campo";
import FotoPerfil from "../shared/FotoPerfil";
import { TIPOS_DOCUMENTO } from "../shared/constantes";

const VACIO = {
  tipoDocumento: "CC", identificacion: "", nombre: "", apellido: "",
  fechaNacimiento: "", sexo: "", telefono: "", correo: "", municipioDane: "",
  direccion: "", fotoPerfil: "", regimenAfiliacion: "", aseguradora: "", acudienteNombre: "",
  acudienteTelefono: "", grupoSanguineo: "", alergias: "", historialClinico: "",
};

export default function PacienteForm({ paciente, error, onGuardar, onCancelar }) {
  const [form, setForm] = useState(paciente ? { ...VACIO, ...paciente } : VACIO);
  const hoy = new Date().toLocaleDateString("sv-SE");
  const cambiar = (e) => setForm((actual) => ({ ...actual, [e.target.name]: e.target.value }));
  const enviar = (e) => { e.preventDefault(); onGuardar(form); };

  return (
    <form onSubmit={enviar} className="formulario formulario-pagina">
      {error && <p className="error">{error}</p>}
      <div className="seccion-formulario">
        <h2>Información personal</h2>
        <p>Datos de identificación y contacto del paciente.</p>
      </div>
      <Campo etiqueta="Tipo de documento">
        <select name="tipoDocumento" value={form.tipoDocumento} onChange={cambiar}>
          {TIPOS_DOCUMENTO.map((tipo) => <option key={tipo} value={tipo}>{tipo}</option>)}
        </select>
      </Campo>
      <Campo etiqueta="Número de documento">
        <input name="identificacion" value={form.identificacion} onChange={cambiar} required maxLength={25} />
      </Campo>
      <Campo etiqueta="Nombres">
        <input name="nombre" value={form.nombre} onChange={cambiar} required maxLength={80} placeholder="Primer y segundo nombre" />
      </Campo>
      <Campo etiqueta="Apellidos">
        <input name="apellido" value={form.apellido} onChange={cambiar} required maxLength={80} placeholder="Primer y segundo apellido" />
      </Campo>
      <Campo etiqueta="Fecha de nacimiento">
        <input type="date" name="fechaNacimiento" max={hoy} value={form.fechaNacimiento || ""} onChange={cambiar} />
      </Campo>
      <Campo etiqueta="Sexo">
        <select name="sexo" value={form.sexo || ""} onChange={cambiar}>
          <option value="">Seleccionar</option><option value="FEMENINO">Femenino</option>
          <option value="MASCULINO">Masculino</option><option value="OTRO">Otro</option>
        </select>
      </Campo>
      <Campo etiqueta="Teléfono">
        <input name="telefono" value={form.telefono || ""} onChange={cambiar} maxLength={25} />
      </Campo>
      <Campo etiqueta="Correo electrónico">
        <input type="email" name="correo" value={form.correo || ""} onChange={cambiar} maxLength={120} />
      </Campo>
      <FotoPerfil value={form.fotoPerfil || ""} onChange={(fotoPerfil) => setForm((actual) => ({ ...actual, fotoPerfil }))} nombre={`${form.nombre} ${form.apellido}`.trim() || "persona"} />
      <Campo etiqueta="Dirección" completo>
        <input name="direccion" value={form.direccion || ""} onChange={cambiar} maxLength={180} />
      </Campo>
      <Campo etiqueta="Código municipio (DANE)">
        <input name="municipioDane" value={form.municipioDane || ""} onChange={cambiar} maxLength={10} />
      </Campo>

      <div className="seccion-formulario">
        <h2>Afiliación y acudiente</h2>
        <p>Información administrativa y datos de contacto alternativo.</p>
      </div>
      <Campo etiqueta="Régimen de afiliación">
        <select name="regimenAfiliacion" value={form.regimenAfiliacion || ""} onChange={cambiar}>
          <option value="">Seleccionar</option><option value="CONTRIBUTIVO">Contributivo</option>
          <option value="SUBSIDIADO">Subsidiado</option><option value="ESPECIAL">Especial</option>
          <option value="NO_AFILIADO">No afiliado</option>
        </select>
      </Campo>
      <Campo etiqueta="EPS / Aseguradora">
        <input name="aseguradora" value={form.aseguradora || ""} onChange={cambiar} maxLength={120} />
      </Campo>
      <Campo etiqueta="Nombre del acudiente">
        <input name="acudienteNombre" value={form.acudienteNombre || ""} onChange={cambiar} maxLength={150} />
      </Campo>
      <Campo etiqueta="Teléfono del acudiente">
        <input name="acudienteTelefono" value={form.acudienteTelefono || ""} onChange={cambiar} maxLength={25} />
      </Campo>

      <div className="seccion-formulario">
        <h2>Información clínica</h2>
        <p>Datos relevantes para la atención del paciente.</p>
      </div>
      <Campo etiqueta="Grupo sanguíneo">
        <select name="grupoSanguineo" value={form.grupoSanguineo || ""} onChange={cambiar}>
          <option value="">No especificado</option>
          {["O+","O-","A+","A-","B+","B-","AB+","AB-"].map((g) => <option key={g}>{g}</option>)}
        </select>
      </Campo>
      <Campo etiqueta="Alergias" completo>
        <textarea name="alergias" rows={3} value={form.alergias || ""} onChange={cambiar} placeholder="Registrar alergias conocidas o escribir Ninguna" />
      </Campo>
      <Campo etiqueta="Historial clínico" completo>
        <textarea name="historialClinico" rows={5} value={form.historialClinico || ""} onChange={cambiar} placeholder="Antecedentes y observaciones relevantes" />
      </Campo>
      <div className="formulario-acciones">
        <button type="button" className="btn btn-suave" onClick={onCancelar}>Cancelar</button>
        <button type="submit" className="btn btn-primario">{paciente ? "Guardar cambios" : "Registrar paciente"}</button>
      </div>
    </form>
  );
}
