import api, { obtenerTodasLasPaginas } from "../shared/api";
import { pacienteDesdeApi, pacienteHaciaApi } from "../shared/normalizadores";

export const listarPacientes = async () =>
  (await obtenerTodasLasPaginas("/pacientes"))
    .filter((persona) => persona.status !== "INACTIVO")
    .map(pacienteDesdeApi);

export const listarPacientesArchivados = async () =>
  (await obtenerTodasLasPaginas("/pacientes/archivados")).map(pacienteDesdeApi);

export const restaurarPaciente = (id) => api.patch(`/pacientes/${id}/restaurar`);

export const crearPaciente = (datos) => api.post("/pacientes", pacienteHaciaApi(datos));
export const actualizarPaciente = (id, datos) => api.put(`/pacientes/${id}`, pacienteHaciaApi(datos));
// Archivar paciente: cambia su estado a INACTIVO, sin borrar el registro.
export const archivarPaciente = (id) => api.patch(`/pacientes/${id}/archivar`);
