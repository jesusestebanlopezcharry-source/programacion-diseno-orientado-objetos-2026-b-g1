import { useEffect, useMemo, useState } from "react";
import { mensajeError } from "../shared/api";
import Avatar from "../shared/Avatar";
import Aviso from "../shared/Aviso";
import Confirmar from "../shared/Confirmar";
import { IconoBuscar, IconoLapiz, IconoMas } from "../shared/Iconos";
import { EDAD_MAYORIA } from "../shared/constantes";
import useAviso from "../shared/useAviso";
import { calcularEdad } from "../shared/utils";
import PacienteForm from "./PacienteForm";
import { listarPacientes, listarPacientesArchivados, crearPaciente, actualizarPaciente, archivarPaciente, restaurarPaciente } from "./pacienteService";

export default function PacientesPage() {
  const [pacientes, setPacientes] = useState([]);
  const [archivados, setArchivados] = useState([]);
  const [vista, setVista] = useState("activos");
  const [cargando, setCargando] = useState(true);
  const [busqueda, setBusqueda] = useState("");
  const [formularioAbierto, setFormularioAbierto] = useState(false);
  const [editando, setEditando] = useState(null);
  const [porArchivar, setPorEliminar] = useState(null);
  const [error, setError] = useState("");
  const { aviso, mostrar, cerrar } = useAviso();

  async function cargar() {
    try { const [activos, inactivos] = await Promise.all([listarPacientes(), listarPacientesArchivados()]); setPacientes(activos); setArchivados(inactivos); }
    catch { mostrar("No se pudo conectar con el servidor", "error"); }
    finally { setCargando(false); }
  }
  useEffect(() => { cargar(); }, []);

  function abrirFormulario(paciente = null) {
    setEditando(paciente);
    setError("");
    setFormularioAbierto(true);
    window.scrollTo({ top: 0, behavior: "smooth" });
  }

  async function guardar(datos) {
    setError("");
    try {
      if (editando) await actualizarPaciente(editando.id, datos);
      else await crearPaciente(datos);
      mostrar(editando ? "Cambios guardados" : "Paciente registrado");
      setFormularioAbierto(false);
      setEditando(null);
      await cargar();
    } catch (err) { setError(mensajeError(err)); }
  }

  async function archivar() {
    try {
      await archivarPaciente(porArchivar.id);
      mostrar("Paciente archivado correctamente");
      await cargar();
    } catch (err) { mostrar(mensajeError(err), "error"); }
    setPorEliminar(null);
  }

  async function restaurar(paciente) {
    try { await restaurarPaciente(paciente.id); mostrar("Paciente restaurado correctamente"); await cargar(); }
    catch (err) { mostrar(mensajeError(err), "error"); }
  }

  const registros = vista === "activos" ? pacientes : archivados;
  const visibles = useMemo(() => registros.filter((p) =>
    `${p.nombre} ${p.apellido} ${p.tipoDocumento} ${p.identificacion} ${p.telefono}`
      .toLowerCase().includes(busqueda.trim().toLowerCase())
  ), [registros, busqueda]);

  return (
    <div>
      <header className="pagina-cabecera">
        <div><h1>Pacientes</h1><p className="subtitulo">{pacientes.length} activos · {archivados.length} archivados</p></div>
        {!formularioAbierto && vista === "activos" && <button className="btn btn-primario" onClick={() => abrirFormulario()}><IconoMas /> Nuevo paciente</button>}
      </header>

      {formularioAbierto && (
        <section className="formulario-panel">
          <header className="formulario-panel-cabecera">
            <div>
              <span className="sobrelinea">{editando ? "ACTUALIZACIÓN DE REGISTRO" : "NUEVO REGISTRO"}</span>
              <h2>{editando ? "Editar paciente" : "Registrar paciente"}</h2>
              <p>Completa la información personal, administrativa y clínica.</p>
            </div>
            <button className="btn btn-suave" onClick={() => { setFormularioAbierto(false); setEditando(null); }}>Cerrar formulario</button>
          </header>
          <PacienteForm key={editando?.id || "nuevo"} paciente={editando} error={error} onGuardar={guardar}
            onCancelar={() => { setFormularioAbierto(false); setEditando(null); }} />
        </section>
      )}

      <div className="pestanas-registros" role="tablist" aria-label="Estado de pacientes">
        <button className={vista === "activos" ? "pestana-registro activa" : "pestana-registro"} onClick={() => { setVista("activos"); setBusqueda(""); }}>Activos <span>{pacientes.length}</span></button>
        <button className={vista === "archivados" ? "pestana-registro activa" : "pestana-registro"} onClick={() => { setVista("archivados"); setBusqueda(""); }}>Archivados <span>{archivados.length}</span></button>
      </div>
      <div className="herramientas">
        <div className="buscador buscador-ancho"><IconoBuscar />
          <input placeholder="Buscar por nombre, cédula o documento de identidad..." value={busqueda} onChange={(e) => setBusqueda(e.target.value)} />
        </div>
        <span className="resultado-busqueda">{visibles.length} resultado(s)</span>
      </div>

      {cargando ? <p className="vacio">Cargando pacientes...</p> :
        registros.length === 0 ? <div className="vacio"><h3>{vista === "activos" ? "Aún no hay pacientes activos" : "No hay pacientes archivados"}</h3><p>{vista === "activos" ? "Registra el primero para poder agendarle una cita." : "Los pacientes que archives aparecerán aquí."}</p>
          {vista === "activos" && <button className="btn btn-primario" onClick={() => abrirFormulario()}><IconoMas /> Nuevo paciente</button>}</div> :
        visibles.length === 0 ? <p className="vacio">Ningún paciente coincide con la búsqueda.</p> :
        <div className="tabla-contenedor"><table>
          <thead><tr><th>Paciente</th><th>Edad</th><th>Grupo sanguíneo</th><th>Contacto</th><th aria-label="Acciones"></th></tr></thead>
          <tbody>{visibles.map((p) => {
            const edad = p.fechaNacimiento ? calcularEdad(p.fechaNacimiento) : null;
            return <tr key={p.id}>
              <td><div className="persona"><Avatar nombre={p.nombre} apellido={p.apellido} fotoPerfil={p.fotoPerfil} /><div>
                <strong>{p.nombre} {p.apellido}</strong><span className="texto-suave">{p.tipoDocumento} {p.identificacion}</span>
              </div></div></td>
              <td>{edad !== null ? <>{edad} años {edad < EDAD_MAYORIA && <span className="etiqueta etiqueta-ambar">Menor</span>}</> : "—"}</td>
              <td>{p.grupoSanguineo || "—"}</td>
              <td><span>{p.telefono || "—"}</span><span className="texto-suave">{p.correo || ""}</span></td>
              <td className="acciones">{vista === "activos" ? <><button className="btn-icono" onClick={() => abrirFormulario(p)} aria-label="Editar paciente"><IconoLapiz /></button>
                <button className="btn btn-archivar" onClick={() => setPorEliminar(p)}>Archivar</button></> : <button className="btn btn-restaurar" onClick={() => restaurar(p)}>Restaurar</button>}</td>
            </tr>;
          })}</tbody>
        </table></div>
      }

      <Confirmar pregunta={porArchivar ? `¿Archivar a ${porArchivar.nombre} ${porArchivar.apellido}?` : null}
        detalle="El paciente dejará de aparecer en los nuevos registros, pero se conservará su historial."
        textoBoton="Archivar paciente" onConfirmar={archivar} onCancelar={() => setPorEliminar(null)} />
      <Aviso aviso={aviso} onCerrar={cerrar} />
    </div>
  );
}
