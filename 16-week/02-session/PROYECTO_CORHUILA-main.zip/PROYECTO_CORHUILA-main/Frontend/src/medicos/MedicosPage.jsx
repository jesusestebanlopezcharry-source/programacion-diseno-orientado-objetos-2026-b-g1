import { useEffect, useMemo, useState } from "react";
import { mensajeError } from "../shared/api";
import Avatar from "../shared/Avatar";
import Aviso from "../shared/Aviso";
import Confirmar from "../shared/Confirmar";
import { IconoBuscar, IconoLapiz, IconoMas } from "../shared/Iconos";
import useAviso from "../shared/useAviso";
import MedicoForm from "./MedicoForm";
import { listarMedicos, listarMedicosArchivados, crearMedico, actualizarMedico, archivarMedico, restaurarMedico } from "./medicoService";

export default function MedicosPage() {
  const [medicos, setMedicos] = useState([]);
  const [archivados, setArchivados] = useState([]);
  const [vista, setVista] = useState("activos");
  const [cargando, setCargando] = useState(true);
  const [busqueda, setBusqueda] = useState("");
  const [formularioAbierto, setFormularioAbierto] = useState(false);
  const [editando, setEditando] = useState(null);
  const [porArchivar, setPorEliminar] = useState(null);
  const [error, setError] = useState("");
  const { aviso, mostrar, cerrar } = useAviso();

  async function cargar() {
    try { const [activos, inactivos] = await Promise.all([listarMedicos(), listarMedicosArchivados()]); setMedicos(activos); setArchivados(inactivos); }
    catch { mostrar("No se pudo conectar con el servidor", "error"); }
    finally { setCargando(false); }
  }
  useEffect(() => { cargar(); }, []);

  function abrirFormulario(medico = null) {
    setEditando(medico); setError(""); setFormularioAbierto(true);
    window.scrollTo({ top: 0, behavior: "smooth" });
  }

  async function guardar(datos) {
    setError("");
    try {
      if (editando) await actualizarMedico(editando.id, datos);
      else await crearMedico(datos);
      mostrar(editando ? "Cambios guardados" : "Médico registrado");
      setFormularioAbierto(false); setEditando(null); await cargar();
    } catch (err) { setError(mensajeError(err)); }
  }

  async function archivar() {
    try { await archivarMedico(porArchivar.id); mostrar("Médico archivado correctamente"); await cargar(); }
    catch (err) { mostrar(mensajeError(err), "error"); }
    setPorEliminar(null);
  }

  async function restaurar(medico) {
    try { await restaurarMedico(medico.id); mostrar("Médico restaurado correctamente"); await cargar(); }
    catch (err) { mostrar(mensajeError(err), "error"); }
  }

  const registros = vista === "activos" ? medicos : archivados;
  const visibles = useMemo(() => registros.filter((m) =>
    `${m.nombre} ${m.apellido} ${m.tipoDocumento} ${m.identificacion} ${m.especialidad} ${m.tarjetaProfesional || ""}`
      .toLowerCase().includes(busqueda.trim().toLowerCase())
  ), [registros, busqueda]);

  return (
    <div>
      <header className="pagina-cabecera">
        <div><h1>Médicos</h1><p className="subtitulo">{medicos.length} activos · {archivados.length} archivados</p></div>
        {!formularioAbierto && vista === "activos" && <button className="btn btn-primario" onClick={() => abrirFormulario()}><IconoMas /> Nuevo médico</button>}
      </header>

      {formularioAbierto && <section className="formulario-panel">
        <header className="formulario-panel-cabecera"><div>
          <span className="sobrelinea">{editando ? "ACTUALIZACIÓN DE REGISTRO" : "NUEVO REGISTRO"}</span>
          <h2>{editando ? "Editar médico" : "Registrar médico"}</h2><p>Completa los datos personales y profesionales.</p>
        </div><button className="btn btn-suave" onClick={() => { setFormularioAbierto(false); setEditando(null); }}>Cerrar formulario</button></header>
        <MedicoForm key={editando?.id || "nuevo"} medico={editando} error={error} onGuardar={guardar}
          onCancelar={() => { setFormularioAbierto(false); setEditando(null); }} />
      </section>}

      <div className="pestanas-registros" role="tablist" aria-label="Estado de médicos">
        <button className={vista === "activos" ? "pestana-registro activa" : "pestana-registro"} onClick={() => { setVista("activos"); setBusqueda(""); }}>Activos <span>{medicos.length}</span></button>
        <button className={vista === "archivados" ? "pestana-registro activa" : "pestana-registro"} onClick={() => { setVista("archivados"); setBusqueda(""); }}>Archivados <span>{archivados.length}</span></button>
      </div>
      <div className="herramientas"><div className="buscador buscador-ancho"><IconoBuscar />
        <input placeholder="Buscar por nombre, cédula, documento o especialidad..." value={busqueda} onChange={(e) => setBusqueda(e.target.value)} />
      </div><span className="resultado-busqueda">{visibles.length} resultado(s)</span></div>

      {cargando ? <p className="vacio">Cargando médicos...</p> :
        registros.length === 0 ? <div className="vacio"><h3>{vista === "activos" ? "Aún no hay médicos activos" : "No hay médicos archivados"}</h3><p>{vista === "activos" ? "Registra el primero para poder agendar citas con él." : "Los médicos que archives aparecerán aquí."}</p>
          {vista === "activos" && <button className="btn btn-primario" onClick={() => abrirFormulario()}><IconoMas /> Nuevo médico</button>}</div> :
        visibles.length === 0 ? <p className="vacio">Ningún médico coincide con la búsqueda.</p> :
        <div className="tabla-contenedor"><table>
          <thead><tr><th>Médico</th><th>Especialidad</th><th>Tarjeta profesional</th><th>Contacto</th><th aria-label="Acciones"></th></tr></thead>
          <tbody>{visibles.map((m) => <tr key={m.id}>
            <td><div className="persona"><Avatar nombre={m.nombre} apellido={m.apellido} fotoPerfil={m.fotoPerfil} /><div>
              <strong>{m.nombre} {m.apellido}</strong><span className="texto-suave">{m.tipoDocumento} {m.identificacion}</span>
            </div></div></td>
            <td><span className="etiqueta etiqueta-primaria">{m.especialidad}</span></td>
            <td>{m.tarjetaProfesional || "—"}</td>
            <td><span>{m.telefono || "—"}</span><span className="texto-suave">{m.correo || ""}</span></td>
            <td className="acciones">{vista === "activos" ? <><button className="btn-icono" onClick={() => abrirFormulario(m)} aria-label="Editar médico"><IconoLapiz /></button>
              <button className="btn btn-archivar" onClick={() => setPorEliminar(m)}>Archivar</button></> : <button className="btn btn-restaurar" onClick={() => restaurar(m)}>Restaurar</button>}</td>
          </tr>)}</tbody>
        </table></div>
      }

      <Confirmar pregunta={porArchivar ? `¿Archivar a ${porArchivar.nombre} ${porArchivar.apellido}?` : null}
        detalle="El médico dejará de aparecer al agendar nuevas citas, pero se conservará el historial."
        textoBoton="Archivar médico" onConfirmar={archivar} onCancelar={() => setPorEliminar(null)} />
      <Aviso aviso={aviso} onCerrar={cerrar} />
    </div>
  );
}
