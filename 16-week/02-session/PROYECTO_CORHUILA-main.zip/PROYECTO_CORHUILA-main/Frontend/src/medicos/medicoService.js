import api, { obtenerTodasLasPaginas } from "../shared/api";
import { medicoDesdeApi, medicoHaciaApi } from "../shared/normalizadores";

export const listarMedicos = async () =>
  (await obtenerTodasLasPaginas("/medicos"))
    .filter((persona) => persona.status !== "INACTIVO")
    .map(medicoDesdeApi);

export const listarMedicosArchivados = async () =>
  (await obtenerTodasLasPaginas("/medicos/archivados")).map(medicoDesdeApi);

export const restaurarMedico = (id) => api.patch(`/medicos/${id}/restaurar`);

export const crearMedico = (datos) => api.post("/medicos", medicoHaciaApi(datos));
export const actualizarMedico = (id, datos) => api.put(`/medicos/${id}`, medicoHaciaApi(datos));
// Archivar médico: cambia su estado a INACTIVO, sin borrar el registro.
export const archivarMedico = (id) => api.patch(`/medicos/${id}/archivar`);
