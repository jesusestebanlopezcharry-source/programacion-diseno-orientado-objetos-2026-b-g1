import { useState } from "react";
import Campo from "../shared/Campo";
import FotoPerfil from "../shared/FotoPerfil";
import { ESPECIALIDADES, TIPOS_DOCUMENTO_MEDICO } from "../shared/constantes";

const VACIO = {
  tipoDocumento: "CC", identificacion: "", nombre: "", apellido: "",
  especialidad: ESPECIALIDADES[0], fotoPerfil: "", tarjetaProfesional: "", telefono: "", correo: "",
};

export default function MedicoForm({ medico, error, onGuardar, onCancelar }) {
  const [form, setForm] = useState(medico ? { ...VACIO, ...medico } : VACIO);
  const cambiar = (e) => setForm((actual) => ({ ...actual, [e.target.name]: e.target.value }));
  const enviar = (e) => { e.preventDefault(); onGuardar(form); };

  return (
    <form onSubmit={enviar} className="formulario formulario-pagina">
      {error && <p className="error">{error}</p>}
      <div className="seccion-formulario">
        <h2>Información personal</h2>
        <p>Datos de identificación y contacto del profesional.</p>
      </div>
      <Campo etiqueta="Tipo de documento">
        <select name="tipoDocumento" value={form.tipoDocumento} onChange={cambiar}>
          {TIPOS_DOCUMENTO_MEDICO.map((tipo) => <option key={tipo}>{tipo}</option>)}
        </select>
      </Campo>
      <Campo etiqueta="Número de documento">
        <input name="identificacion" value={form.identificacion} onChange={cambiar} required maxLength={25} />
      </Campo>
      <Campo etiqueta="Nombres">
        <input name="nombre" value={form.nombre} onChange={cambiar} required maxLength={80} placeholder="Primer y segundo nombre" />
      </Campo>
      <Campo etiqueta="Apellidos">
        <input name="apellido" value={form.apellido} onChange={cambiar} required maxLength={80} placeholder="Primer y segundo apellido" />
      </Campo>
      <Campo etiqueta="Teléfono">
        <input name="telefono" value={form.telefono || ""} onChange={cambiar} maxLength={25} />
      </Campo>
      <Campo etiqueta="Correo electrónico">
        <input type="email" name="correo" value={form.correo || ""} onChange={cambiar} maxLength={120} />
      </Campo>
      <FotoPerfil value={form.fotoPerfil || ""} onChange={(fotoPerfil) => setForm((actual) => ({ ...actual, fotoPerfil }))} nombre={`${form.nombre} ${form.apellido}`.trim() || "persona"} />
      <div className="seccion-formulario">
        <h2>Información profesional</h2>
        <p>Especialidad y acreditación del médico.</p>
      </div>
      <Campo etiqueta="Especialidad">
        <select name="especialidad" value={form.especialidad} onChange={cambiar} required>
          {ESPECIALIDADES.map((esp) => <option key={esp}>{esp}</option>)}
        </select>
      </Campo>
      <Campo etiqueta="Tarjeta profesional">
        <input name="tarjetaProfesional" value={form.tarjetaProfesional || ""} onChange={cambiar} maxLength={50} />
      </Campo>
      <div className="formulario-acciones">
        <button type="button" className="btn btn-suave" onClick={onCancelar}>Cancelar</button>
        <button type="submit" className="btn btn-primario">{medico ? "Guardar cambios" : "Registrar médico"}</button>
      </div>
    </form>
  );
}
