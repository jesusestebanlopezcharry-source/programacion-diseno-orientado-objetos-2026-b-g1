# Frontend - Agenda Médica

## Requisitos
- Node.js 20.19+ o 22.12+
- Backend Spring Boot ejecutándose en `http://localhost:8080` (o configurar `VITE_API_URL`).

## Instalación y ejecución
```bash
npm install
npm run dev
```

Para generar la versión de producción:
```bash
npm run build
```

Si el backend está en otra dirección, copia `.env.example` como `.env` y cambia `VITE_API_URL`.

## Cambios principales
- Adaptación de los modelos del frontend a los nombres reales de las entidades Java.
- Lectura de todas las páginas que devuelve Spring Data `Page`.
- Formularios amplios para registrar y editar pacientes y médicos, con los campos disponibles en el backend.
- Búsqueda por nombre, documento, cédula y especialidad.
- Agenda agrupable por fecha, médico o especialidad.
- Búsqueda de paciente y médico al crear una cita.
- Selección de fecha y hora mediante una cuadrícula de horarios en intervalos de 15 minutos.
- Cancelación lógica de citas y desactivación lógica de pacientes/médicos desde la interfaz.
- Captura de fotografía con la cámara del dispositivo o selección de una imagen local para pacientes y médicos.
- Compresión automática de fotografías a JPEG (máximo 500 KB) y envío como `fotoPerfil` Base64 al backend.
